#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <gtk/gtk.h>
#include"fct.h"
char ch[100];
enum
{
  EJ,
  EM,
  EA,
  ETEMPS,
  EENTREE,
  EPLAT,
  EDESSERT,
  COLUMNS,
};
GtkListStore *adstore;
GtkTreeViewColumn *adcolumn;
GtkCellRenderer *cellad;
FILE *f;
void ajout_menu(menu m)
{
    FILE *f;

    f=fopen("menu.txt","a");
    if (f!=NULL)
{
    fprintf(f,"%d %d %d %s %s %s %s \n",m.d.jour,m.d.mois,m.d.annee,m.temps,m.menu.entree,m.menu.plat_principale,m.menu.dessert);
}
    fclose(f);
}
void supprimer_menu(int jour,int mois,int annee,char temps[])
    {
        FILE *f=NULL;
        FILE *s=NULL;
        char ch2[200],ch3[200],ch4[200],ch5[200];
        int a,b,c,x,test=0;
        f=fopen("menu.txt","r");
        s=fopen("sup.txt","a");
        if(f!=NULL)
        {
            while(fscanf(f,"%d %d %d %s %s %s %s \n",&a,&b,&c,ch2,ch3,ch4,ch5)!=EOF)
            {
if (a!=jour||b!=mois||c!=annee||strcmp(temps,ch2)!=0)
{
                    fprintf(s,"%d %d %d %s %s %s %s \n",a,b,c,ch2,ch3,ch4,ch5);
}
else
 test=1;

            }
        }

        fclose(f);
        fclose(s);
        remove("menu.txt");
        rename("sup.txt","menu.txt");
if (test==0)
{
printf("le menu n'existe pas\n");
}
    }

void modifier_menu(menu me)
{
FILE *f=NULL;
        FILE *s=NULL;
        char ch2[200],ch3[200],ch4[200],ch5[200];
        int a,b,c,x,test=0;
        f=fopen("menu.txt","r");
        s=fopen("sup.txt","a");
        if(f!=NULL)
        {
            while(fscanf(f,"%d %d %d %s %s %s %s \n",&a,&b,&c,ch2,ch3,ch4,ch5)!=EOF)
            {
if (a!=me.d.jour||b!=me.d.mois||c!=me.d.annee||strcmp(me.temps,ch2)!=0)
{
                    fprintf(s,"%d %d %d %s %s %s %s \n",a,b,c,ch2,ch3,ch4,ch5);
}
else
{
 test=1;
fprintf(s,"%d %d %d %s %s %s %s \n",a,b,c,ch2,me.menu.entree,me.menu.plat_principale,me.menu.dessert);
}

            }
        }

        fclose(f);
        fclose(s);
        remove("menu.txt");
        rename("sup.txt","menu.txt");
if (test==0)
{
printf("le menu n'existe pas\n");
}
    }
int rechercher_menu(int jo,int mo,int an,char temps1[],char plat[])
{
FILE *f=NULL;
        FILE *s=NULL;
        char ch2[200],ch3[200],ch4[200],ch5[200];
        int a,b,c,x,test=0;
        f=fopen("menu.txt","r");
        s=fopen("rech.txt","w");
        if(f!=NULL)
        {
            while(fscanf(f,"%d %d %d %s %s %s %s \n",&a,&b,&c,ch2,ch3,ch4,ch5)!=EOF)
            {
if (jo==a && mo==b && an==c && strcmp(temps1,ch2)==0 && strcmp(plat,ch4)==0 )
{
test=1;
                    fprintf(s,"%d %d %d %s %s %s %s \n",a,b,c,ch2,ch3,ch4,ch5);
}

            }
        }

        fclose(f);
        fclose(s);
return test;
}

int rechercher_menu1(char plat[])
{
FILE *f=NULL;
        FILE *s=NULL;
        char ch2[200],ch3[200],ch4[200],ch5[200];
        int a,b,c,x,test=0;
        f=fopen("menu.txt","r");
        s=fopen("rech1.txt","w");
        if(f!=NULL)
        {
            while(fscanf(f,"%d %d %d %s %s %s %s \n",&a,&b,&c,ch2,ch3,ch4,ch5)!=EOF)
            {
if (strcmp(plat,ch4)==0)
{
test=1;
                    fprintf(s,"%d %d %d %s %s %s %s \n",a,b,c,ch2,ch3,ch4,ch5);
}

            }
        }

        fclose(f);
        fclose(s);
return test;
}
int rechercher_menu2(int jo,int mo,int an,char temps1[])
{
FILE *f=NULL;
        FILE *s=NULL;
        char ch2[200],ch3[200],ch4[200],ch5[200];
        int a,b,c,x,test=0;
        f=fopen("menu.txt","r");
        s=fopen("rech2.txt","w");
        if(f!=NULL)
        {
            while(fscanf(f,"%d %d %d %s %s %s %s \n",&a,&b,&c,ch2,ch3,ch4,ch5)!=EOF)
            {
if (jo==a && mo==b && an==c && strcmp(temps1,ch2)==0)
{
test=1;
                    fprintf(s,"%d %d %d %s %s %s %s \n",a,b,c,ch2,ch3,ch4,ch5);
}

            }
        }

        fclose(f);
        fclose(s);
return test;
}

void afficher(GtkWidget *treeview1,char ch[])
{
GtkListStore *store;
 store=NULL;
 FILE *f;
menu m;
 store=gtk_tree_view_get_model(treeview1);
adstore = gtk_list_store_new(7,
                                     G_TYPE_INT,
                                     G_TYPE_INT,
                                     G_TYPE_INT,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
				     G_TYPE_STRING,
				     G_TYPE_STRING);
f=fopen(ch,"r");
while (fscanf(f,"%d %d %d %s %s %s %s \n",&m.d.jour,&m.d.mois,&m.d.annee,m.temps,m.menu.entree,m.menu.plat_principale,m.menu.dessert)!=EOF)
{
GtkTreeIter pIter;
         gtk_list_store_append(adstore, &pIter);
gtk_list_store_set(adstore, &pIter,
                            0,m.d.jour,
                            1,m.d.mois,
			    2,m.d.annee,
                            3,m.temps,
                            4,m.menu.entree,
                            5,m.menu.plat_principale,
                            6,m.menu.dessert,-1);}
        fclose(f);
if(store==0)
	{
cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("JOUR",
                                                            cellad,
                                                            "text", 0,
                                                            NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);
cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("MOIS",
                                                            cellad,
                                                            "text", 1,
                                                            NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);
cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("ANNEE",
                                                            cellad,
                                                            "text", 2,
                                                            NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);
cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("TEMPS",
                                                            cellad,
                                                            "text", 3,
                                                            NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);
cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("ENTREE",
                                                            cellad,
                                                            "text", 4,
                                                            NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);
cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("PLAT_PRINCIPALE",
                                                            cellad,
                                                            "text", 5,
                                                            NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);
cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("DESSERT",
                                                            cellad,
                                                            "text", 6,
                                                            NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);
}
gtk_tree_view_set_model ( GTK_TREE_VIEW (treeview1),
                                  GTK_TREE_MODEL(adstore)  );

}
void meilleur_menu(char meill11[],char meill12[],char meill13[],char meill21[],char meill22[],char meill23[],char meill31[],char meill32[],char meill33[])
    {
        FILE *f=NULL;
	FILE *meill=NULL;
        int a,b,c,j1,m1,j2,m2,j3,m3,cmp1=1000,cmp2=1000,cmp3=1000,x,y,z;
        f=fopen("dechets.txt","r");
        if(f!=NULL)
        {

            while(fscanf(f,"%d %d %d \n",&a,&b,&c)!=EOF)
            {
                 if(cmp1>c&&b==1)
                 {
                    cmp1=c;
                    j1=a;
                    m1=b;
                 }
		 if(cmp2>c&&b==2)
                 {
                    cmp2=c;
                    j2=a;
                    m2=b;
                 }
		 if(cmp3>c&&b==3)
                 {
                    cmp3=c;
                    j3=a;
                    m3=b;
                 }
            }
	}
	sprintf(meill11,"%d",j1);
	sprintf(meill12,"%d",m1);
	sprintf(meill13,"%d",cmp1);
	sprintf(meill21,"%d",j2);
	sprintf(meill22,"%d",m2);
	sprintf(meill23,"%d",cmp2);
	sprintf(meill31,"%d",j3);
	sprintf(meill32,"%d",m3);
	sprintf(meill33,"%d",cmp3);
 }
