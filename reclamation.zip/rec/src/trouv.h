int verif(char log[], char Pw[]);
