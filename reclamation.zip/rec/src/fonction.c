#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "fonction.h"
#include <gtk/gtk.h>


void ajouter_reclamation(reclamation t)
{

 FILE *fa;
  fa=fopen("bloc.txt","a+");
  if(fa!=NULL) 
  {
  fprintf(fa,"%s %s %s %d/%d/%d  \n",t.identifiant,t.type,t.nature,t.produit.jour,t.produit.mois,t.produit.annee);
  fclose(fa);
}

}


enum   
{       
        EIDENTIFIANT,
	ETYPE,
	ENATURE,
        EDATE,
     
        COLUMNS
};
void afficher_reclamation(GtkWidget *liste)
{
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;
        char identifiant [30];
        char type [30];
	char nature [30];
        char date_de_validite [30] ;
        
        store=NULL;
       FILE *f;
	store=gtk_tree_view_get_model(liste);	
	if (store==NULL)
	{

                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" identifiant", renderer, "text",EIDENTIFIANT,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" type ", renderer, "text",ETYPE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);	
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" reclamation ", renderer, "text",ENATURE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);	

	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  date_of_validation", renderer, "text",EDATE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
             

column = gtk_tree_view_column_new();

renderer = gtk_cell_renderer_text_new();

gtk_tree_view_column_pack_start(column, renderer, TRUE);



	
               
	
	}

	
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,  G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	f = fopen("bloc.txt", "r");
	
	if(f==NULL)
	{

		return;
	}		
	else 

	{ f = fopen("bloc.txt", "a+");
              while(fscanf(f," %s %s %s %s  \n",identifiant,type,nature,date_de_validite)!=EOF)
		{
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter, EIDENTIFIANT, identifiant, ETYPE, type, ENATURE, nature, EDATE, date_de_validite, -1);
		}
		fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),  GTK_TREE_MODEL (store));
    g_object_unref (store);
	}
}

void supprimer_reclamation(char id[])
{

reclamation t;

FILE*fa;
FILE*ffact;

char date_de_validite[50];
char type[50];
char identifiant[50];
char nature[50];



fa = fopen("bloc.txt","r");
ffact = fopen("bloc2.txt","w+");


while (fscanf(fa,"%s %s %s %s  \n",t.identifiant,t.type,t.nature,date_de_validite)!=EOF)
 {

            if(strcmp(t.identifiant,id)!=0)
            {
                fprintf(ffact,"%s %s %s %s  \n",t.identifiant,t.type,t.nature,date_de_validite);
                
        }
 


    }

    fclose(ffact);
    fclose(fa);

     remove("bloc.txt");
     rename("bloc2.txt","bloc.txt");
}



void modifier_t(  char id[], char typee[], char naturee[], char date1[] )
   {
reclamation t;

FILE*fa;
FILE*ffact;

char date_de_validite[50];
char type[50];
char identifiant[50];
char nature[50];



fa = fopen("bloc.txt","r");
ffact = fopen("bloc2.txt","w+");


while (fscanf(fa,"%s %s %s %s  \n",t.identifiant,t.type,t.nature,date_de_validite)!=EOF)
 {

            if(strcmp(t.identifiant,id)!=0)
            {
                fprintf(ffact,"%s %s %s %s  \n",t.identifiant,t.type,t.nature,date_de_validite);
            }
	else  
	   {
		fprintf(ffact,"%s %s %s %s  \n",t.identifiant,typee,naturee,date1);
	   }  }

    fclose(ffact);
    fclose(fa);

     remove("bloc.txt");
     rename("bloc2.txt","bloc.txt");
}

void service_plus_reclame(reclamation t,char reclamation[])
{
    
   FILE *f=NULL;
    f=fopen("bloc.txt","r");

     

char date_de_validite[50];
char type[50];
char identifiant[50];
char nature[50];
int   nb0=0,nb1=0;
    if (f!=NULL)
    {

while (fscanf(f,"%s %s %s %s  \n",t.identifiant,t.type,t.nature,date_de_validite)!=EOF)
 {

       if (strcmp(t.type,"hebergement")==0)
         nb0++;

         else {
            if (strcmp(t.type,"restauration")==0)
            nb1++;
           };
    }
}

printf("%d%d",nb0,nb1);
if (nb0>nb1)
   {

    printf("le service le plus reclame est le FOYER  \n");
     }
else
  {
 printf("le service le plus reclame est le RESTAURANT  \n");
     }
    }


