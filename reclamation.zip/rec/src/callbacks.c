#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"
#include "trouv.h"
int nb0,nb1;
void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *username, *password, *window2;
char user[20];
char pasw[20];
int trouve;
username=lookup_widget (button,"entry1");
password=lookup_widget (button,"entry2");

strcpy(user, gtk_entry_get_text(GTK_ENTRY(username)));
strcpy(pasw, gtk_entry_get_text(GTK_ENTRY(password)));
trouve=verif(user,pasw);

if(trouve==1)
{
GtkWidget *window2;
window2=create_window2();
gtk_widget_show (window2);
}

}


void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window3;
window3=create_window3();
gtk_widget_show (window3);
}


void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1;
window1=create_window1();
gtk_widget_show (window1);
}




void
on_button10_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2;
window2=create_window2();
gtk_widget_show (window2);
}


void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window4, *window5;
window4=lookup_widget(button,"window4");
gtk_widget_destroy(window4);
window5=lookup_widget(button,"window5");
window5=create_window5();
gtk_widget_show(window5);




}


void
on_button13_clicked                    (GtkWidget       *obj, gpointer         user_data)
{
GtkWidget *entry3; 
GtkWidget *entry9; 
GtkWidget *combobox1;
GtkWidget  *spin3;
GtkWidget  *spin4;
GtkWidget  *spin5;
GtkWidget *pRadio1;
GtkWidget *pRadio3;

reclamation t;




entry3=lookup_widget(obj,"entry3");
combobox1=lookup_widget(obj,"combobox1");
spin3=lookup_widget(obj,"spinbutton3");
spin4=lookup_widget(obj,"spinbutton4");
spin5=lookup_widget(obj,"spinbutton5");
entry9=lookup_widget(obj,"entry9");
strcpy(t.identifiant,gtk_entry_get_text(GTK_ENTRY(entry3)));
strcpy(t.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(t.nature,gtk_entry_get_text(GTK_ENTRY(entry9)));
t.produit.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin3));
t.produit.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin4));
t.produit.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin5));
strcpy(t.nature,gtk_entry_get_text(GTK_ENTRY(entry9)));
 if (strcmp(t.type,"hebergement")==0)
         nb0++;

         else {
            if (strcmp(t.type,"restauration")==0)
            nb1++;
           };



ajouter_reclamation(t);
}


void
on_button12_clicked                    (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *window5;
	GtkWidget *treeview11;

	window5=lookup_widget(obj,"window5");
	treeview11=lookup_widget(window5,"treeview1");

	afficher_reclamation(treeview11);

}

void
on_button14_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window3;
window3=create_window3();
gtk_widget_show (window3);
}


void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window6;
window6=create_window6();
gtk_widget_show (window6);
}


void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window7;
window7=create_window7();
gtk_widget_show (window7);
}


void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window5;
window5=create_window5();
gtk_widget_show (window5);
}


void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window7;
window7=create_window7();
gtk_widget_show (window7);
}


void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window4;
window4=create_window4();
gtk_widget_show (window4);

}


void
on_button15_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
char id[50];

	GtkWidget *entry4;
	entry4=lookup_widget(button,"entry4");
	strcpy(id,gtk_entry_get_text(GTK_ENTRY(entry4)));

	supprimer_reclamation(id);
	
}


void
on_button16_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window6, *window5;
window6=lookup_widget(button,"window6");
gtk_widget_destroy(window6);
window5=lookup_widget(button,"window5");
window5=create_window5();
gtk_widget_show(window5);

}


void
on_button19_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window7, *window5;
window7=lookup_widget(button,"window7");
gtk_widget_destroy(window7);
window5=lookup_widget(button,"window5");
window5=create_window5();
gtk_widget_show(window5);


}


void
on_button17_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
char idd[50];
	char typee[50];
	char date1[50];
	char naturee[50];
	GtkWidget *entry5;
	GtkWidget *entry6;
	GtkWidget *entry8; 
	GtkWidget *entry7;
	
	entry5=lookup_widget(button,"entry5");
	strcpy(idd,gtk_entry_get_text(GTK_ENTRY(entry5)));
	entry6=lookup_widget(button,"entry6");
	strcpy(typee,gtk_entry_get_text(GTK_ENTRY(entry6)));
	entry8=lookup_widget(button,"entry8");
	strcpy(date1,gtk_entry_get_text(GTK_ENTRY(entry8)));
	entry7=lookup_widget(button,"entry7");
	strcpy(naturee,gtk_entry_get_text(GTK_ENTRY(entry7)));
	modifier_t(idd,typee,naturee,date1);
}


void
on_button18_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *entry5;
GtkWidget *entry6;
GtkWidget *entry7;
GtkWidget *entry8;
FILE *fa;
char id1[50];
reclamation t;
char date_de_validite[50];
fa=fopen("bloc.txt","r");
entry5=lookup_widget(button,"entry5");
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(entry5)));
if (fa!=NULL)
 {
    	while(fscanf(fa,"%s %s %s %s \n",t.identifiant,t.type,t.nature,date_de_validite)!=EOF)
 {
			if(strcmp(id1,t.identifiant)==0){

				entry5=lookup_widget(button,"entr5");
				entry6=lookup_widget(button,"entry6");
				entry7=lookup_widget(button,"entry7");
				entry8=lookup_widget(button,"entry8");
				gtk_entry_set_text(GTK_ENTRY(entry5),t.identifiant);
				gtk_entry_set_text(GTK_ENTRY(entry6),t.type);
				gtk_entry_set_text(GTK_ENTRY(entry7),t.nature);
				gtk_entry_set_text(GTK_ENTRY(entry8),date_de_validite);
				
			}
				
				

		}

}



}


void
on_button21_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button20_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *entry9;
GtkWidget *entry10;
GtkWidget *entry12;
FILE *fa;
char id1[50];
reclamation t;
char date_de_validite[50];
fa=fopen("bloc.txt","r");
entry9=lookup_widget(button,"entry9");
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(entry9)));
if (fa!=NULL)
 {
    	while(fscanf(fa,"%s %s %s  \n",t.identifiant,t.type,date_de_validite)!=EOF)
 {
			if(strcmp(id1,t.identifiant)==0){

				entry9=lookup_widget(button,"entry9");
				entry10=lookup_widget(button,"entry10");
				entry12=lookup_widget(button,"entry12");
				gtk_entry_set_text(GTK_ENTRY(entry9),t.identifiant);
				gtk_entry_set_text(GTK_ENTRY(entry10),t.type);
				gtk_entry_set_text(GTK_ENTRY(entry12),date_de_validite);
				
			}
				
				

		}

}



}





void
on_button22_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window8;
window8=create_window8();
gtk_widget_show (window8);

}
void
on_button23_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window8, *window5;
window8=lookup_widget(button,"window8");
gtk_widget_destroy(window8);
window5=lookup_widget(button,"window5");
window5=create_window5();
gtk_widget_show(window5);

}






void
on_button24_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *window8;
window8=create_window8();
gtk_widget_show (window8);

}


void
on_button25_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
char text1[100]="";
GtkWidget *output;
if (nb0>nb1)
   {
output= lookup_widget(button,"label61");
gtk_label_set_text(GTK_LABEL(output),"hebergement");
}
else 
  {
output= lookup_widget(button,"label61");
gtk_label_set_text(GTK_LABEL(output),"restauration");
}}

void
on_button28_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window5, *window6;
window5=lookup_widget(button,"window5");
gtk_widget_destroy(window5);
window6=lookup_widget(button,"window6");
window6=create_window6();
gtk_widget_show(window6);
}


void
on_button27_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window5, *window7;
window5=lookup_widget(button,"window5");
gtk_widget_destroy(window5);
window7=lookup_widget(button,"window7");
window7=create_window7();
gtk_widget_show(window7);



}


void
on_button26_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window5, *window4;
window5=lookup_widget(button,"window5");
gtk_widget_destroy(window5);
window4=lookup_widget(button,"window4");
window4=create_window4();
gtk_widget_show(window4);
}


void
on_button29_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window5, *window7;
window5=lookup_widget(button,"window5");
gtk_widget_destroy(window5);
window7=lookup_widget(button,"window7");
window7=create_window7();
gtk_widget_show(window7);
}


void
on_button30_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *window5, *window8;
window5=lookup_widget(button,"window5");
gtk_widget_destroy(window5);
window8=lookup_widget(button,"window8");
window8=create_window8();
gtk_widget_show(window8);
}

