#include <gtk/gtk.h>
typedef struct
{

        int jour;
	int mois;
	int annee;


}date_de_validite;


typedef struct
{
	char id [30];
        char identifiant [30];
        char type [30];
	char nature [30];
	date_de_validite produit;


}reclamation;



void ajouter_reclamation(reclamation t);
void afficher_reclamation(GtkWidget *liste);
void modifier_t(  char id[], char typee[], char naturee[], char date1[] );
void supprimer_reclamation(char id[]);
void service_plus_reclame(reclamation t,char reclamation[]);
