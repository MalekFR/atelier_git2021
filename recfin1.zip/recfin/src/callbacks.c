#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"
#include "trouv.h"
int nb0,nb1,confirmer;
char M[20];
void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *username, *password, *window2;
char user[20];
char pasw[20];
int trouve;
username=lookup_widget (button,"entry1");
password=lookup_widget (button,"entry2");

strcpy(user, gtk_entry_get_text(GTK_ENTRY(username)));
strcpy(pasw, gtk_entry_get_text(GTK_ENTRY(password)));
trouve=verif(user,pasw);

if(trouve==1)
{
GtkWidget *window2;
window2=create_window2();
gtk_widget_show (window2);
}

}


void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window3;
window3=create_window3();
gtk_widget_show (window3);
}


void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1;
window1=create_window1();
gtk_widget_show (window1);
}




void
on_button10_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2;
window2=create_window2();
gtk_widget_show (window2);
}


void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window4, *window5;
window4=lookup_widget(button,"window4");
gtk_widget_destroy(window4);
window5=lookup_widget(button,"window5");
window5=create_window5();
gtk_widget_show(window5);




}


void
on_button13_clicked                    (GtkWidget       *obj, gpointer         user_data)
{
GtkWidget *entry3; 
GtkWidget *entry9; 
GtkWidget *combobox1;
GtkWidget  *spin3;
GtkWidget  *spin4;
GtkWidget  *spin5;
GtkWidget *pRadio1;
GtkWidget *pRadio3;

reclamation t;




entry3=lookup_widget(obj,"entry3");
combobox1=lookup_widget(obj,"combobox1");
spin3=lookup_widget(obj,"spinbutton3");
spin4=lookup_widget(obj,"spinbutton4");
spin5=lookup_widget(obj,"spinbutton5");
entry9=lookup_widget(obj,"entry9");
strcpy(t.identifiant,gtk_entry_get_text(GTK_ENTRY(entry3)));
strcpy(t.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(t.nature,gtk_entry_get_text(GTK_ENTRY(entry9)));
t.produit.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin3));
t.produit.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin4));
t.produit.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin5));
strcpy(t.nature,gtk_entry_get_text(GTK_ENTRY(entry9)));
 if (strcmp(t.type,"hebergement")==0)
         nb0++;

         else {
            if (strcmp(t.type,"restauration")==0)
            nb1++;
           };



ajouter_reclamation(t);
}


void
on_button12_clicked                    (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *window5;
	GtkWidget *treeview11;

	window5=lookup_widget(obj,"window5");
	treeview11=lookup_widget(window5,"treeview1");

	afficher_reclamation(treeview11);

}

void
on_button14_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window3;
window3=create_window3();
gtk_widget_show (window3);
}


void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window6;
window6=create_window6();
gtk_widget_show (window6);
}


void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window7;
window7=create_window7();
gtk_widget_show (window7);
}


void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window5;
window5=create_window5();
gtk_widget_show (window5);
}


void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window7;
window7=create_window7();
gtk_widget_show (window7);
}


void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window4;
window4=create_window4();
gtk_widget_show (window4);

}


void
on_button15_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
char id[50];

	GtkWidget *entry4;
	entry4=lookup_widget(button,"entry4");
	strcpy(id,gtk_entry_get_text(GTK_ENTRY(entry4)));

	if(strcmp(M,"oui"))
{
	supprimer_reclamation(id);
}
	
}


void
on_button16_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window6, *window5;
window6=lookup_widget(button,"window6");
gtk_widget_destroy(window6);
window5=lookup_widget(button,"window5");
window5=create_window5();
gtk_widget_show(window5);

}









void
on_button21_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button20_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *entry9;
GtkWidget *entry10;
GtkWidget *entry12;
FILE *fa;
char id1[50];
reclamation t;
char date_de_validite[50];
fa=fopen("bloc.txt","r");
entry9=lookup_widget(button,"entry9");
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(entry9)));
if (fa!=NULL)
 {
    	while(fscanf(fa,"%s %s %s  \n",t.identifiant,t.type,date_de_validite)!=EOF)
 {
			if(strcmp(id1,t.identifiant)==0){

				entry9=lookup_widget(button,"entry9");
				entry10=lookup_widget(button,"entry10");
				entry12=lookup_widget(button,"entry12");
				gtk_entry_set_text(GTK_ENTRY(entry9),t.identifiant);
				gtk_entry_set_text(GTK_ENTRY(entry10),t.type);
				gtk_entry_set_text(GTK_ENTRY(entry12),date_de_validite);
				
			}
				
				

		}

}



}





void
on_button22_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window8;
window8=create_window8();
gtk_widget_show (window8);

}






void
on_button24_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *window8;
window8=create_window8();
gtk_widget_show (window8);

}



void
on_button28_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window5, *window6;
window5=lookup_widget(button,"window5");
gtk_widget_destroy(window5);
window6=lookup_widget(button,"window6");
window6=create_window6();
gtk_widget_show(window6);
}


void
on_button27_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window5, *window7;
window5=lookup_widget(button,"window5");
gtk_widget_destroy(window5);
window7=lookup_widget(button,"window7");
window7=create_window7();
gtk_widget_show(window7);



}


void
on_button26_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window5, *window4;
window5=lookup_widget(button,"window5");
gtk_widget_destroy(window5);
window4=lookup_widget(button,"window4");
window4=create_window4();
gtk_widget_show(window4);
}


void
on_button29_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window5, *window7;
window5=lookup_widget(button,"window5");
gtk_widget_destroy(window5);
window7=lookup_widget(button,"window7");
window7=create_window7();
gtk_widget_show(window7);
}


void
on_button30_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *window5, *window8;
window5=lookup_widget(button,"window5");
gtk_widget_destroy(window5);
window8=lookup_widget(button,"window8");
window8=create_window8();
gtk_widget_show(window8);
}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{strcpy(M,"oui");}
}


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{strcpy(M,"non");}
}


void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_CHECK_BUTTON(togglebutton)))
{confirmer=1;}
else{confirmer=0;}
}


void
on_rbutton11_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window4, *window5;
window4=lookup_widget(button,"window4");
gtk_widget_destroy(window4);
window5=lookup_widget(button,"window5");
window5=create_window5();
gtk_widget_show(window5);
}


void
on_rbutton13_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *rentry3; 
GtkWidget *rentry9; 
GtkWidget *rcombobox1;
GtkWidget  *rspin3;
GtkWidget  *rspin4;
GtkWidget  *rspin5;
GtkWidget *rpRadio1;
GtkWidget *rpRadio3;

reclamation t;




rentry3=lookup_widget(button,"rentry3");
rcombobox1=lookup_widget(button,"rcombobox1");
rspin3=lookup_widget(button,"rspinbutton3");
rspin4=lookup_widget(button,"rspinbutton4");
rspin5=lookup_widget(button,"rspinbutton5");
rentry9=lookup_widget(button,"rentry9");
strcpy(t.identifiant,gtk_entry_get_text(GTK_ENTRY(rentry3)));
strcpy(t.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(rcombobox1)));
strcpy(t.nature,gtk_entry_get_text(GTK_ENTRY(rentry9)));
t.produit.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(rspin3));
t.produit.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(rspin4));
t.produit.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(rspin5));
strcpy(t.nature,gtk_entry_get_text(GTK_ENTRY(rentry9)));
 if (strcmp(t.type,"hebergement")==0)
         nb0++;

         else {
            if (strcmp(t.type,"restauration")==0)
            nb1++;
           };



ajouter_reclamation(t);
}




void
on_rtreeview1_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_rbutton26_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window5, *window4;
window5=lookup_widget(button,"window5");
gtk_widget_destroy(window5);
window4=lookup_widget(button,"window4");
window4=create_window4();
gtk_widget_show(window4);
}


void
on_rbutton28_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window5, *window6;
window5=lookup_widget(button,"window5");
gtk_widget_destroy(window5);
window6=lookup_widget(button,"window6");
window6=create_window6();
gtk_widget_show(window6);
}


void
on_rbutton29_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window5, *window7;
window5=lookup_widget(button,"window5");
gtk_widget_destroy(window5);
window7=lookup_widget(button,"window7");
window7=create_window7();
gtk_widget_show(window7);
}


void
on_rbutton27_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window5, *window7;
window5=lookup_widget(button,"window5");
gtk_widget_destroy(window5);
window7=lookup_widget(button,"window7");
window7=create_window7();
gtk_widget_show(window7);
}


void
on_rbutton30_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window5, *window8;
window5=lookup_widget(button,"window5");
gtk_widget_destroy(window5);
window8=lookup_widget(button,"window8");
window8=create_window8();
gtk_widget_show(window8);
}


void
on_rbutton12_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window5;
	GtkWidget *rtreeview11;

	window5=lookup_widget(button,"window5");
	rtreeview11=lookup_widget(window5,"rtreeview1");

	afficher_reclamation(rtreeview11);
}


void
on_rbutton16_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window6, *window5;
window6=lookup_widget(button,"window6");
gtk_widget_destroy(window6);
window5=lookup_widget(button,"window5");
window5=create_window5();
gtk_widget_show(window5);
}


void
on_rbutton15_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
char id[50];

	GtkWidget *rentry4;
	rentry4=lookup_widget(button,"rentry4");
	strcpy(id,gtk_entry_get_text(GTK_ENTRY(rentry4)));

	if(strcmp(M,"oui"))
{
	supprimer_reclamation(id);
}
}


void
on_rradiobutton1_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{strcpy(M,"non");}
}


void
on_rradiobutton2_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{strcpy(M,"oui");}
}


void
on_rcheckbutton1_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_CHECK_BUTTON(togglebutton)))
{confirmer=1;}
else{confirmer=0;}
}


void
on_rbutton18_clicked                   (GtkButton       *button,
                                        gpointer         user_data)

{

GtkWidget *rentry5;
GtkWidget *rentry6;
GtkWidget *rentry7;
GtkWidget *rentry8;
FILE *fa;
char id1[50];
reclamation t;
char date_de_validite[50];
fa=fopen("bloc.txt","r");
rentry5=lookup_widget(button,"rentry5");
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(rentry5)));
if (fa!=NULL)
 {
    	while(fscanf(fa,"%s %s %s %s \n",t.identifiant,t.type,t.nature,date_de_validite)!=EOF)
 {
			if(strcmp(id1,t.identifiant)==0){

				rentry5=lookup_widget(button,"rentr5");
				rentry6=lookup_widget(button,"rentry6");
				rentry7=lookup_widget(button,"rentry7");
				rentry8=lookup_widget(button,"rentry8");
				gtk_entry_set_text(GTK_ENTRY(rentry5),t.identifiant);
				gtk_entry_set_text(GTK_ENTRY(rentry6),t.type);
				gtk_entry_set_text(GTK_ENTRY(rentry7),t.nature);
				gtk_entry_set_text(GTK_ENTRY(rentry8),date_de_validite);
				
			}
				
				

		}

}


}





void
on_rbutton19_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window7, *window5;
window7=lookup_widget(button,"window7");
gtk_widget_destroy(window7);
window5=lookup_widget(button,"window5");
window5=create_window5();
gtk_widget_show(window5);
}


void
on_rbutton17_clicked                   (GtkButton       *button,
                                        gpointer         user_data)

{
char idd[50];
	char typee[50];
	char date1[50];
	char naturee[50];
	GtkWidget *rentry5;
	GtkWidget *rentry6;
	GtkWidget *rentry8; 
	GtkWidget *rentry7;
	
	rentry5=lookup_widget(button,"rentry5");
	strcpy(idd,gtk_entry_get_text(GTK_ENTRY(rentry5)));
	rentry6=lookup_widget(button,"rentry6");
	strcpy(typee,gtk_entry_get_text(GTK_ENTRY(rentry6)));
	rentry8=lookup_widget(button,"rentry8");
	strcpy(date1,gtk_entry_get_text(GTK_ENTRY(rentry8)));
	rentry7=lookup_widget(button,"rentry7");
	strcpy(naturee,gtk_entry_get_text(GTK_ENTRY(rentry7)));
	if((confirmer==1)&&(strcmp(typee,"hebergement")==0||strcmp(typee,"restauration")==0))
	{
	modifier_t(idd,typee,naturee,date1);
	}
}




void
on_rbutton23_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window8, *window5;
window8=lookup_widget(button,"window8");
gtk_widget_destroy(window8);
window5=lookup_widget(button,"window5");
window5=create_window5();
gtk_widget_show(window5);
}


void
on_rbutton25_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
char text1[100]="";
GtkWidget *output;
if (nb0>nb1)
   {
output= lookup_widget(button,"rlabel61");
gtk_label_set_text(GTK_LABEL(output),"hebergement");
}
else if (nb0<nb1)
  {
output= lookup_widget(button,"rlabel61");
gtk_label_set_text(GTK_LABEL(output),"restauration");
}
else 
{
output= lookup_widget(button,"rlabel61");
gtk_label_set_text(GTK_LABEL(output),"egaux");
}
}

/*GtkWidget *output;
reclamation t;
char ee[200]="00";

service_plus_reclame(t,ee);
output=lookup_widget(button,"rlabel61");
gtk_label_set_text(GTK_LABEL(output),ee);

}*/

