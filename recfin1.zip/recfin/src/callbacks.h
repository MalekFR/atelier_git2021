#include <gtk/gtk.h>


void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button10_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkWidget       *obj, gpointer         user_data);

void
on_button12_clicked                    (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button15_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button16_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button19_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button17_clicked                    (GtkWidget        *button,
                                        gpointer         user_data);

void
on_button18_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button21_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button20_clicked                    (GtkButton       *button,
                                        gpointer         user_data);


void
on_button22_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
void
on_button23_clicked                    (GtkButton       *button,
                                        gpointer         user_data);







void
on_button24_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button25_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button28_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button27_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button26_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button29_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button30_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_rbutton11_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_rbutton13_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_rtreeview1_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_rbutton26_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_rbutton28_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_rbutton29_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_rbutton27_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_rbutton30_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_rbutton12_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_rbutton16_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_rbutton15_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_rradiobutton1_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_rradiobutton2_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_rcheckbutton1_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_rbutton18_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_rbutton19_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_rbutton17_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_rbutton23_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_rbutton25_clicked                   (GtkButton       *button,
                                        gpointer         user_data);
