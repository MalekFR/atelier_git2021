#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <gtk/gtk.h>
#include"fct.h"
char ch[100];
enum
{
  ENOM,
  EREFERENCE,
  ETYPE,
  EQUANTITE,
  EEMPLACEMENT,
  EJ,
  EM,
  EA,
  COLUMNS,
};
GtkListStore *adstore;
GtkTreeViewColumn *adcolumn;
GtkCellRenderer *cellad;
FILE *f;
void ajout_stock(stock s)
{
    FILE *f;

    f=fopen("stock.txt","a");
    if (f!=NULL)
{
    fprintf(f,"%d %d %d %s %s %s %s %s \n",s.d.jour,s.d.mois,s.d.annee,s.Bloc,s.Reference,s.nom,s.QA,s.kype);
}
    fclose(f);
}
void supprimer_stock(char Reference[])
    {
        FILE *f=NULL;
        FILE *s=NULL;
        char ch2[200],ch3[200],ch4[200],ch5[200],ch6[200];
        int a,b,c,x,test=0;
        f=fopen("stock.txt","r");
        s=fopen("sup.txt","a");
        if(f!=NULL)
        {
            while(fscanf(f,"%d %d %d %s %s %s %s %s \n",&a,&b,&c,ch2,ch3,ch4,ch5,ch6)!=EOF)
            {
if (strcmp(Reference,ch3)!=0)
{
                    fprintf(s,"%d %d %d %s %s %s %s %s \n",a,b,c,ch2,ch3,ch4,ch5,ch6);
}
else
 test=1;

            }
        }

        fclose(f);
        fclose(s);
        remove("stock.txt");
        rename("sup.txt","stock.txt");

 }

void modifier_stock(stock se)
{
FILE *f=NULL;
        FILE *k=NULL;
        char ch2[200],ch3[200],ch4[200],ch5[200],ch6[200];
        int a,b,c,x,test=0;
        f=fopen("stock.txt","r");
        k=fopen("sup.txt","a");
        if(f!=NULL)
        {
            while(fscanf(f,"%d %d %d %s %s %s %s %s \n",&a,&b,&c,ch2,ch3,ch4,ch5,ch6)!=EOF)
            {
if (a!=se.d.jour||b!=se.d.mois||c!=se.d.annee||strcmp(se.Bloc,ch2)!=0)
{
                    fprintf(k,"%d %d %d %s %s %s %s %s \n",a,b,c,ch2,ch3,ch4,ch5,ch6);
}
else
{
 test=1;
fprintf(k,"%d %d %d %s %s %s %s %s\n",a,b,c,ch2,se.Reference,se.nom,se.QA,se.kype);
}

            }
        }

        fclose(f);
        fclose(k);
        remove("stock.txt");
        rename("sup.txt","stock.txt");

    }
int rechercher_stock(int jo,int mo,int an,char nom[])
{
FILE *f=NULL;
        FILE *s=NULL;
        char ch2[200],ch3[200],ch4[200],ch5[200],ch6[200];
        int a,b,c,x,test=0;
        f=fopen("stock.txt","r");
        s=fopen("rech.txt","w");
        if(f!=NULL)
        {
            while(fscanf(f,"%d %d %d %s %s %s %s %s \n",&a,&b,&c,ch2,ch3,ch4,ch5,ch6)!=EOF)
            {
if (jo==a && mo==b && an==c && strcmp(nom,ch4)==0 )
{
test=1;
                    fprintf(s,"%d %d %d %s %s %s %s %s \n",a,b,c,ch2,ch3,ch4,ch5,ch6);
}

            }
        }

        fclose(f);
        fclose(s);
return test;
}
int rechercher_stock1(char nom[])
{
FILE *f=NULL;
        FILE *k=NULL;
        char ch2[200],ch3[200],ch4[200],ch5[200],ch6[200];
        int a,b,c,x,test=0;
        f=fopen("stock.txt","r");
        k=fopen("rech1.txt","w");
        if(f!=NULL)
        {
            while(fscanf(f,"%d %d %d %s %s %s %s %s \n",&a,&b,&c,ch2,ch3,ch4,ch5,ch6)!=EOF)
            {
if (strcmp(nom,ch4)==0)
{
test=1;
                    fprintf(k,"%d %d %d %s %s %s %s %s \n",a,b,c,ch2,ch3,ch4,ch5,ch6);
}

            }
        }

        fclose(f);
        fclose(k);
return test;
}
int rechercher_stock3()
{
FILE *f=NULL;
        FILE *k=NULL;
        char ch2[200],ch3[200],ch4[200],ch5[200],ch6[200];
        int a,b,c,x,test=0;
        f=fopen("stock.txt","r");
        k=fopen("rech3.txt","w");
        if(f!=NULL)
        {
            while(fscanf(f,"%d %d %d %s %s %s %s %s \n",&a,&b,&c,ch2,ch3,ch4,ch5,ch6)!=EOF)
            {
if (strcmp(ch5,"0")==0)
{
test=1;
                    fprintf(k,"%d %d %d %s %s %s %s %s \n",a,b,c,ch2,ch3,ch4,ch5,ch6);
}

            }
        }

        fclose(f);
        fclose(k);
return test;
}
int rechercher_stock2(int jo,int mo,int an)
{
FILE *f=NULL;
        FILE *k=NULL;
        char ch2[200],ch3[200],ch4[200],ch5[200],ch6[200];
        int a,b,c,x,test=0;
        f=fopen("stock.txt","r");
        k=fopen("rech2.txt","w");
        if(f!=NULL)
        {
            while(fscanf(f,"%d %d %d %s %s %s %s %s \n",&a,&b,&c,ch2,ch3,ch4,ch5,ch6)!=EOF)
            {
if (jo==a && mo==b && an==c )
{
test=1;
                    fprintf(k,"%d %d %d %s %s %s %s %s \n",a,b,c,ch2,ch3,ch4,ch5,ch6);
}

            }
        }

        fclose(f);
        fclose(k);
return test;
}

void afficher(GtkWidget *treeview1,char ch[])
{
GtkListStore *store;
 store=NULL;
 FILE *f;
stock s;
 store=gtk_tree_view_get_model(treeview1);
adstore = gtk_list_store_new(8,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
				     G_TYPE_STRING,
				     G_TYPE_STRING,
                                     G_TYPE_INT,
                                     G_TYPE_INT,
                                     G_TYPE_INT);
f=fopen(ch,"r");
while (fscanf(f,"%d %d %d %s %s %s %s %s \n",&s.d.jour,&s.d.mois,&s.d.annee,s.Bloc,s.Reference,s.nom,s.QA,s.kype)!=EOF)
{
GtkTreeIter pIter;
         gtk_list_store_append(adstore, &pIter);
gtk_list_store_set(adstore, &pIter,
                            0,s.nom,
                            1,s.Reference,
			    2,s.kype,
                            3,s.QA,
                            4,s.Bloc,
                            5,s.d.jour,
                            6,s.d.mois,
                            7,s.d.annee,-1);}
        fclose(f);
if(store==0)
	{
cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("NOM",
                                                            cellad,
                                                            "text", 0,
                                                            NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);
cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("REFERENCE",
                                                            cellad,
                                                            "text", 1,
                                                            NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);
cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("TYPE",
                                                            cellad,
                                                            "text", 2,
                                                            NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);
cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("QUANTITE",
                                                            cellad,
                                                            "text", 3,
                                                            NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);
cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("EMPLACEMENT",
                                                            cellad,
                                                            "text", 4,
                                                            NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);
cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("JOUR",
                                                            cellad,
                                                            "text", 5,
                                                            NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);
cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("MOIS",
                                                            cellad,
                                                            "text", 6,
                                                            NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);
cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("ANNEE",
                                                            cellad,
                                                            "text", 7,
                                                            NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);



}
gtk_tree_view_set_model ( GTK_TREE_VIEW (treeview1),
                                  GTK_TREE_MODEL(adstore)  );

}
void Repture_stock(char Rep11[])
    {
        
 }
