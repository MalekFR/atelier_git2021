typedef struct
{
	int jour;
	int mois;
	int annee;
}date;

typedef struct
{
	char Reference[50];
	char nom[50];
	char QA[50];
        date  d;
	char Bloc[50];
        char kype[50];
	

}stock;

void afficher(GtkWidget *treeview1, char ch[]);
void ajout_stock(stock s);
void supprimer_stock(char Reference[]);
int rechercher_stock(int jo,int mo,int an,char nom[]);
int rechercher_stock1(char nom[]); /* recherche par nom */
int rechercher_stock3();
int rechercher_stock2(int jo,int mo,int an); /*recherhce par delais*/
void modifier_stock(stock se);
void Repture_stock(char Rep11[]);



