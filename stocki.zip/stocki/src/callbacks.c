#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "fct.h"
int x=0;
int t[2]={0,0};
char ch[100];
stock se;


void
on_button_ajout_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *ajouter;
ajouter = create_ajout();
  gtk_widget_show (ajouter);

}

void
on_button_mod_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *modif;
char chj[10],chm[10],cha[10];
modif = create_modifier();
  gtk_widget_show (modif);


gtk_entry_set_text(GTK_ENTRY(lookup_widget(modif,"entry4")),se.Reference);
gtk_entry_set_text(GTK_ENTRY(lookup_widget(modif,"entry5")),se.nom);
gtk_entry_set_text(GTK_ENTRY(lookup_widget(modif,"entry6")),se.QA);

}


void
on_button_supp_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
supprimer_stock(se.Reference);
GtkWidget *confirmesupprimer;
confirmesupprimer=lookup_widget(button,"affichage");
strcpy(ch,"stock.txt");
afficher(lookup_widget(button,"treeview1"),ch);

}


void
on_button_meill_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
int l ;
l=rechercher_stock3();
if (l==1)
{
GtkWidget *affiche;
affiche=lookup_widget(button,"affichage");
strcpy(ch,"rech3.txt");
afficher(lookup_widget(affiche,"treeview1"),ch);
}
}


void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{t[0]=1;
}
else
{t[0]=0;}

}


void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{t[1]=1;
}
else
{t[1]=0;}

}


void
on_button_rech_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
int l;
if (t[0]==1 && t[1]==1)
{
GtkWidget *entry_nom;
char r[100];
entry_nom=lookup_widget(button,"entry7");
strcpy(r,gtk_entry_get_text(GTK_ENTRY(entry_nom) ) );
GtkWidget *Jour1,*Mois1,*Annee1;
int jo,mo,an;

Jour1=lookup_widget(button,"entry_jour1");
Mois1=lookup_widget(button,"entry_mois1");
Annee1=lookup_widget(button,"entry_annee1");
jo=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Jour1));
mo=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Mois1));
an=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Annee1));

l=rechercher_stock(jo,mo,an,r);
if (l==1)
{
GtkWidget *affiche;
affiche=lookup_widget(button,"affichage");
strcpy(ch,"rech.txt");
afficher(lookup_widget(affiche,"treeview1"),ch);
}
else
{
GtkWidget *mess;
mess = create_message();
  gtk_widget_show (mess);
}
}
else
{
if (t[0]==1)
{
GtkWidget *entry_nom;
char r[100];
entry_nom=lookup_widget(button,"entry7");
strcpy(r,gtk_entry_get_text(GTK_ENTRY(entry_nom) ) );
l=rechercher_stock1(r);
if (l==1)
{
GtkWidget *affiche;
affiche=lookup_widget(button,"affichage");
strcpy(ch,"rech1.txt");
afficher(lookup_widget(affiche,"treeview1"),ch);
}
else
{
GtkWidget *mess;
mess = create_message();
  gtk_widget_show (mess);
}
}
if (t[1]==1)
{
GtkWidget *Jour1,*Mois1,*Annee1;
int jo,mo,an;

Jour1=lookup_widget(button,"entry_jour1");
Mois1=lookup_widget(button,"entry_mois1");
Annee1=lookup_widget(button,"entry_annee1");

jo=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Jour1));
mo=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Mois1));
an=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Annee1));

l=rechercher_stock2(jo,mo,an);
if (l==1)
{
GtkWidget *affiche;
affiche=lookup_widget(button,"affichage");
strcpy(ch,"rech2.txt");
afficher(lookup_widget(affiche,"treeview1"),ch);
}
else
{
GtkWidget *mess;
mess = create_message();
  gtk_widget_show (mess);
}
}

}
}


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=2;}
 
}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=1;}

}


void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=3;}

}
void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=4;}


}
void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Ajout;
Ajout=lookup_widget(button,"ajout");
gtk_widget_destroy(Ajout);

}


void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
stock s;
GtkWidget *affichage;
GtkWidget *entry_Reference, *entry_nom, *entry_QA, *entry_bloc ,*Jour,*Mois,*Annee,*combobox2;
GtkWidget *Ajout;
Ajout=lookup_widget(button,"ajout");

entry_Reference=lookup_widget(button,"entry_Reference");
entry_nom=lookup_widget(button,"entry_nom");
entry_QA=lookup_widget(button,"entry_QA");
Jour=lookup_widget(button,"entry_jour");
Mois=lookup_widget(button,"entry_mois");
Annee=lookup_widget(button,"entry_annee");
combobox2=lookup_widget(button,"combobox2");

strcpy(s.Reference,gtk_entry_get_text(GTK_ENTRY(entry_Reference) ) );
strcpy(s.nom,gtk_entry_get_text(GTK_ENTRY(entry_nom) ) );
strcpy(s.QA,gtk_entry_get_text(GTK_ENTRY(entry_QA) ) );
strcpy(s.kype,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2))); 

strcpy(s.Reference,gtk_entry_get_text(GTK_ENTRY(entry_Reference) ) );
strcpy(s.nom,gtk_entry_get_text(GTK_ENTRY(entry_nom) ) );
strcpy(s.QA,gtk_entry_get_text(GTK_ENTRY(entry_QA) ) );

if (x==1){
strcpy(s.Bloc,"Bloc_A");}
else 
if (x==2){
strcpy(s.Bloc,"Bloc_B");}
else 
if (x==3){
strcpy(s.Bloc,"Bloc_C");}
else
{strcpy(s.Bloc,"Bloc_D");}

 s.d.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Jour));
 s.d.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Mois));
 s.d.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Annee));



ajout_stock(s);
gtk_widget_destroy(Ajout);
}


void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *mod;
mod=lookup_widget(button,"modifier");
gtk_widget_destroy(mod);

}


void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *entry_Reference, *entry_nom, *entry_QA,*mod;
mod=lookup_widget(button,"modifier");
entry_Reference=lookup_widget(button,"entry4");
entry_nom=lookup_widget(button,"entry5");
entry_QA=lookup_widget(button,"entry6");
 strcpy(se.Reference,gtk_entry_get_text(GTK_ENTRY(entry_Reference) ) );
 strcpy(se.nom,gtk_entry_get_text(GTK_ENTRY(entry_nom) ) );
 strcpy(se.QA,gtk_entry_get_text(GTK_ENTRY(entry_QA) ) );
modifier_stock(se);
gtk_widget_destroy(mod);

}




void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
        gchar *nom;
	gchar  *Reference;
        gchar *kype;				
	gchar *QA;
        gchar  *Bloc;
        gint *j;
        gint *m;
        gint *a;
        
       GtkTreeIter iter;
	
	

	GtkTreeModel *model =gtk_tree_view_get_model(treeview);

	if (gtk_tree_model_get_iter(model, &iter , path))
	{ 
	  gtk_tree_model_get (GTK_LIST_STORE(model), &iter,  0, &nom,1,&Reference,2,&kype,3,&QA,4,&Bloc,5,&j,6,&m,7,&a,-1);
	  se.d.jour=j;
	  se.d.mois=m;
	  se.d.annee=a;
	  strcpy(se.Bloc,Bloc);
	  strcpy(se.Reference,Reference);
	  strcpy(se.nom,nom);
	  strcpy(se.QA,QA);
          strcpy(se.kype,kype);

	}


}

void
on_button11_clicked                    (GtkButton       *button)
{
GtkWidget *affiche;
affiche=lookup_widget(button,"affichage");
strcpy(ch,"stock.txt");
afficher(lookup_widget(affiche,"treeview1"),ch);
}


void
on_button12_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *meill;
meill=lookup_widget(button,"meilleur");
gtk_widget_destroy(meill);

}


void
on_button13_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *mess;
mess=lookup_widget(button,"message");
gtk_widget_destroy(mess);

}


