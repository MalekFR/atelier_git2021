#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <stdbool.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "fct.h"
int x=0;
int t[2]={0,0};
char ch[100];
menu me;


void
on_button_ajout_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *ajouter;
ajouter = create_ajout();
  gtk_widget_show (ajouter);

}

void
on_button_mod_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *modif;
char chj[10],chm[10],cha[10];
modif = create_modifier();
  gtk_widget_show (modif);

GtkWidget* msgjour=lookup_widget(modif,"label21");
sprintf(chj,"%d",me.d.jour);
gtk_label_set_text(GTK_LABEL(msgjour),chj);
gtk_widget_show(msgjour);

GtkWidget* msgmois=lookup_widget(modif,"label23");
sprintf(chm,"%d",me.d.mois);
gtk_label_set_text(GTK_LABEL(msgmois),chm);
gtk_widget_show(msgmois);


GtkWidget* msgannee=lookup_widget(modif,"label25");
sprintf(cha,"%d",me.d.annee);
gtk_label_set_text(GTK_LABEL(msgannee),cha);
gtk_widget_show(msgannee);

gtk_entry_set_text(GTK_ENTRY(lookup_widget(modif,"entry4")),me.menu.entree);
gtk_entry_set_text(GTK_ENTRY(lookup_widget(modif,"entry5")),me.menu.plat_principale);
gtk_entry_set_text(GTK_ENTRY(lookup_widget(modif,"entry6")),me.menu.dessert);

}


void
on_button_supp_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *confirmesupprimer;
confirmesupprimer=lookup_widget(button,"affichage");
strcpy(ch,"menu.txt");


GtkWidget *pInfo;
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_QUESTION,GTK_BUTTONS_YES_NO,"Voulez-vous vraiment\nsupprimer ce menu?");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_YES:
	gtk_widget_destroy(pInfo);
        supprimer_menu(me.d.jour,me.d.mois,me.d.annee,me.temps);
	break;
	case GTK_RESPONSE_NO:
	gtk_widget_destroy(pInfo);
	break;
}
afficher(lookup_widget(button,"treeview1"),ch);


}


void
on_button_meill_clicked                ()
{
char ch1[100],ch2[100],ch3[100],ch4[100],ch5[100],ah1[1000],ah2[1000],ah3[1000];
int a1,a2,a3,a4,tmp1=1000000,tmp2=1000000,tmp3=10000003;
int b1,b2,b3,b4,bpe1,bpe2,bpe3,bpe4,bde1,bde2,bde3,bde4,bdi1,bdi2,bdi3,bdi4;
//char meill11[10],meill12[10],meill13[10],meill21[10],meill22[10],meill23[10],meill31[10],meill32[10],meill33[10];
GtkWidget *meill;
meill = create_meilleur();
  gtk_widget_show (meill);
FILE *f=NULL;
f=fopen("dechets.txt","r");
while(fscanf(f,"%d %d %d %s %d \n",&a1,&a2,&a3,ch1,&a4)!=EOF)
{
if (tmp1>a4 && strcmp(ch1,"petit_dejeuner")==0)
{
bpe1=a1;
bpe2=a2;
bpe3=a3;
//strcpy(ch2pe,ch1);
bpe4=a4;
tmp1=a4;
}
else if (tmp2>a4 && strcmp(ch1,"dejeuner")==0)
{
bde1=a1;
bde2=a2;
bde3=a3;
//strcpy(ch2de,ch1);
bde4=a4;
tmp2=a4;
}
else if (tmp3>a4 && strcmp(ch1,"dinner")==0)
{
bdi1=a1;
bdi2=a2;
bdi3=a3;
//strcpy(ch2di,ch1);
bdi4=a4;
tmp3=a4;
}
}
fclose(f);

sprintf(ah1,"meilleur petir dejeuner le: %d/%d/%d avec dechet :%d",bpe1,bpe2,bpe3,bpe4);
GtkWidget* m1=lookup_widget(meill,"label183meill");
gtk_label_set_text(GTK_LABEL(m1),ah1);
gtk_widget_show(m1);

sprintf(ah2,"meilleur dejeuner le: %d/%d/%d avec dechet :%d",bde1,bde2,bde3,bde4);
GtkWidget* m2=lookup_widget(meill,"label184meill");
gtk_label_set_text(GTK_LABEL(m2),ah2);
gtk_widget_show(m2);

sprintf(ah3,"meilleur dinner le: %d/%d/%d avec dechet :%d",bdi1,bdi2,bdi3,bdi4);
GtkWidget* m3=lookup_widget(meill,"label185meill");
gtk_label_set_text(GTK_LABEL(m3),ah3);
gtk_widget_show(m3);

}


void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{t[0]=1;
}
else
{t[0]=0;}

}


void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{t[1]=1;
}
else
{t[1]=0;}

}


void
on_button_rech_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
int l;
if (t[0]==1 && t[1]==1)
{
GtkWidget *entry_plat;
char r[100];
entry_plat=lookup_widget(button,"entry7");
strcpy(r,gtk_entry_get_text(GTK_ENTRY(entry_plat) ) );
GtkWidget *Jour1,*Mois1,*Annee1,*Combobox1;
int jo,mo,an;
char temps1[100];
Jour1=lookup_widget(button,"entry_jour1");
Mois1=lookup_widget(button,"entry_mois1");
Annee1=lookup_widget(button,"entry_annee1");
Combobox1=lookup_widget(button,"combobox1");
jo= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Jour1));
mo= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Mois1));
an= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Annee1));
strcpy(temps1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox1)));
l=rechercher_menu(jo,mo,an,temps1,r);
if (l==1)
{
GtkWidget *affiche;
affiche=lookup_widget(button,"affichage");
strcpy(ch,"rech.txt");
afficher(lookup_widget(affiche,"treeview1"),ch);
}
else
{
GtkWidget *mess;
mess = create_message();
  gtk_widget_show (mess);
}
}
else
{
if (t[0]==1)
{
GtkWidget *entry_plat;
char r[100];
entry_plat=lookup_widget(button,"entry7");
strcpy(r,gtk_entry_get_text(GTK_ENTRY(entry_plat) ) );
l=rechercher_menu1(r);
if (l==1)
{
GtkWidget *affiche;
affiche=lookup_widget(button,"affichage");
strcpy(ch,"rech1.txt");
afficher(lookup_widget(affiche,"treeview1"),ch);
}
else
{
GtkWidget *mess;
mess = create_message();
  gtk_widget_show (mess);
}
}
if (t[1]==1)
{
GtkWidget *Jour1,*Mois1,*Annee1,*Combobox1;
int jo,mo,an;
char temps1[100];
Jour1=lookup_widget(button,"entry_jour1");
Mois1=lookup_widget(button,"entry_mois1");
Annee1=lookup_widget(button,"entry_annee1");
Combobox1=lookup_widget(button,"combobox1");
jo= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Jour1));
mo= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Mois1));
an= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Annee1));
strcpy(temps1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox1)));
l=rechercher_menu2(jo,mo,an,temps1);
if (l==1)
{
GtkWidget *affiche;
affiche=lookup_widget(button,"affichage");
strcpy(ch,"rech2.txt");
afficher(lookup_widget(affiche,"treeview1"),ch);
}
else
{
GtkWidget *mess;
mess = create_message();
  gtk_widget_show (mess);
}
}

}
}


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=2;}
 
}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=1;}

}


void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=3;}

}
void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Ajout;
Ajout=lookup_widget(button,"ajout");
gtk_widget_destroy(Ajout);

}


void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
menu m;
GtkWidget *affichage;
GtkWidget *entry_entree, *entry_plat, *entry_dessert, *entry_temps /*,*Jour,*Mois,*Annee*/,*bloc;
GtkCalendar *ajc;
guint day,month,year;
GtkWidget *Ajout;
Ajout=lookup_widget(button,"ajout");
bloc=lookup_widget(button,"ajc");
entry_entree=lookup_widget(button,"entry_entree");
entry_plat=lookup_widget(button,"entry_plat");
entry_dessert=lookup_widget(button,"entry_dinner");
/*Jour=lookup_widget(button,"entry_jour");
Mois=lookup_widget(button,"entry_mois");
Annee=lookup_widget(button,"entry_annee");*/
gtk_calendar_get_date(GTK_CALENDAR(bloc),&day,&month,&year);
m.d.jour=year;
m.d.mois=month+1;
m.d.annee=day;
printf("kkk=%d",m.d.jour);

 strcpy(m.menu.entree,gtk_entry_get_text(GTK_ENTRY(entry_entree) ) );
 strcpy(m.menu.plat_principale,gtk_entry_get_text(GTK_ENTRY(entry_plat) ) );
 strcpy(m.menu.dessert,gtk_entry_get_text(GTK_ENTRY(entry_dessert) ) );
 if (x==1){
strcpy(m.temps,"petit_dejeuner");}
else 
if (x==2){
strcpy(m.temps,"dejeuner");}
else
{strcpy(m.temps,"dinner");}

 /*m.d.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Jour));
 m.d.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Mois));
 m.d.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Annee));

*/

ajout_menu(m);
gtk_widget_destroy(Ajout);
}


void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *mod;
mod=lookup_widget(button,"modifier");
gtk_widget_destroy(mod);

}


void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *entry_entree, *entry_plat, *entry_dessert,*mod;
mod=lookup_widget(button,"modifier");
entry_entree=lookup_widget(button,"entry4");
entry_plat=lookup_widget(button,"entry5");
entry_dessert=lookup_widget(button,"entry6");
 strcpy(me.menu.entree,gtk_entry_get_text(GTK_ENTRY(entry_entree) ) );
 strcpy(me.menu.plat_principale,gtk_entry_get_text(GTK_ENTRY(entry_plat) ) );
 strcpy(me.menu.dessert,gtk_entry_get_text(GTK_ENTRY(entry_dessert) ) );
modifier_menu(me);
gtk_widget_destroy(mod);

}




void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
        gint *j;
        gint *m;
        gint *a;
        gchar  *temps;
	gchar  *entree;
        gchar *plat;
	gchar *dessert;
      
       GtkTreeIter iter;
	
	

	GtkTreeModel *model =gtk_tree_view_get_model(treeview);

	if (gtk_tree_model_get_iter(model, &iter , path))
	{ 
	  gtk_tree_model_get (GTK_LIST_STORE(model), &iter,  0, &j,1,&m,2,&a,3,&temps,4,&entree,5,&plat,6,&dessert,-1);
	  me.d.jour=j;
	  me.d.mois=m;
	  me.d.annee=a;
	  strcpy(me.temps,temps);
	  strcpy(me.menu.entree,entree);
	  strcpy(me.menu.plat_principale,plat);
	  strcpy(me.menu.dessert,dessert);


	}


}

void
on_button11_clicked                    (GtkButton       *button)
{
GtkWidget *affiche;
affiche=lookup_widget(button,"affichage");
strcpy(ch,"menu.txt");
afficher(lookup_widget(affiche,"treeview1"),ch);
}


void
on_button12_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *meill;
meill=lookup_widget(button,"meilleur");
gtk_widget_destroy(meill);

}


void
on_button13_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *mess;
mess=lookup_widget(button,"message");
gtk_widget_destroy(mess);

}

void
on_button14meill_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *meill;
meill=lookup_widget(button,"meilleur");


GtkWidget *jou,*mou,*aou,*tou,*cou,*dech,*bb1,*bb2,*bb3,*bb4;
char bb[50];
FILE *f=NULL;
jou=lookup_widget(button,"spinbutton1meill");
mou=lookup_widget(button,"spinbutton2meill");
aou=lookup_widget(button,"spinbutton3meill");
dech=lookup_widget(button,"spinbutton4meill");
 bb1 = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jou));
 bb2 = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mou));
 bb3 = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(aou));
 bb4 = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jou));
cou=lookup_widget(button,"combobox3meill");
strcpy(bb,gtk_combo_box_get_active_text(GTK_COMBO_BOX(cou)));
f=fopen("dechets.txt","a");
if(f!=NULL)
  { fprintf(f,"%d %d %d %s %d \n",bb1,bb2,bb3,bb,bb4);}
fclose(f);
gtk_widget_destroy(meill);
on_button_meill_clicked                ();
}

